
class MarkerInfo:
	def __init__(self, rvec, tvec, time_since_last, ID):
		self.rvec = rvec
		self.tvec = tvec
		self.time = time_since_last
		self.id = ID
