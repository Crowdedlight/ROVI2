
"use strict";

let marker_info = require('./marker_info.js');

module.exports = {
  marker_info: marker_info,
};
